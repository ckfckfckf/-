# 网站配置信息

## 基本信息
- **网站名称**: 广州爵泰家具有限公司
- **标语**: 爵无仅有，泰然安居
- **域名**: 暂未配置（当前使用 IP: 47.252.74.114）
- **部署路径**: `/usr/share/nginx/html/`
- **源码路径**: `/home/admin/.openclaw/workspace/furniture-website-v2/`

## 技术栈
- **前端**: HTML5, CSS3, JavaScript (ES6+)
- **构建工具**: Python 脚本 (build.py)
- **Web 服务器**: Nginx
- **响应式设计**: 支持移动端适配
- **多语言支持**: 中文/英文切换

## 功能特性
- ✅ 视频首屏展示
- ✅ 产品分类展示
- ✅ 工程案例地图展示
- ✅ 多语言切换（本地存储）
- ✅ 表单提交功能
- ✅ 滚动动画效果
- ✅ 产品详情页

## 文件结构说明
```
furniture-website-v2/
├── src/              # 源HTML模板文件
├── data/             # 结构化数据
│   ├── products.json # 产品数据
│   └── projects.json # 工程案例数据
├── dist/             # 构建输出目录
├── build.py          # 构建脚本
├── website-docs/     # 网站文档
└── README.md         # 项目总说明
```

## 部署信息
- **服务器IP**: 47.252.74.114
- **Nginx状态**: 运行中
- **最后部署时间**: 2026-02-24 22:30
- **部署用户**: admin
- **权限**: 需要 sudo 权限进行文件复制

## 维护指南
1. 编辑 `data/` 目录下的 JSON 文件添加内容
2. 运行 `python build.py` 生成新网站
3. 使用 `sudo cp -r dist/* /usr/share/nginx/html/` 部署
4. 清除浏览器缓存查看更新效果