// 产品详情页动态加载器
class ProductLoader {
    constructor() {
        this.products = null;
        this.categories = null;
        this.currentProductId = null;
        this.language = localStorage.getItem('site_lang') || 'zh';
    }

    async loadProducts() {
        try {
            const response = await fetch('data/products.json');
            const data = await response.json();
            this.products = data.products || [];
            this.categories = data.categories || [];
            return { products: this.products, categories: this.categories };
        } catch (error) {
            console.error('Failed to load products:', error);
            return null;
        }
    }

    getProductById(productId) {
        if (!this.products) return null;
        return this.products.find(item => item.id === productId);
    }

    getCategoryById(categoryId) {
        if (!this.categories) return null;
        return this.categories.find(cat => cat.id === categoryId);
    }

    // 从URL参数获取产品ID
    getProductIdFromUrl() {
        const urlParams = new URLSearchParams(window.location.search);
        return urlParams.get('id') || 'milano-sofa'; // 默认米兰沙发
    }

    // 生成完整的HTML内容
    generateProductHTML(product, category) {
        if (!product || !category) {
            return `
                <div class="error">
                    ${this.translate('error_not_found')}
                </div>
            `;
        }

        // 获取图片
        const images = product.images || [];
        const mainImage = images[0] ? images[0].replace('w=800', 'w=1200') : '';
        const thumbImages = images.map(img => img.replace('w=800', 'w=300'));

        // 获取规格信息
        const specs = this.language === 'zh' ? product.specifications : product.specifications_en;
        let specsHtml = '';
        if (specs) {
            specsHtml = `
                <table class="specs-table">
                    ${Object.entries(specs).map(([key, value]) => `
                        <tr><td>${key}</td><td>${value}</td></tr>
                    `).join('')}
                </table>
            `;
        }

        // 生成颜色选项（示例）
        const colorOptions = `
            <div class="color-options">
                <div class="color-swatch c-caramel active" onclick="selectColor(this)" title="焦糖色"></div>
                <div class="color-swatch c-black" onclick="selectColor(this)" title="经典黑"></div>
                <div class="color-swatch c-ivory" onclick="selectColor(this)" title="象牙白"></div>
            </div>
        `;

        return `
            <!-- 面包屑导航 -->
            <div class="breadcrumb">
                <a href="index.html" data-i18n="nav_home">${this.translate('nav_home')}</a> <span>/</span> 
                <a href="products.html" data-i18n="nav_products">${this.translate('nav_products')}</a> <span>/</span> 
                <a href="products.html?category=${product.category}" data-i18n="cat_${product.category}">${this.translate(`cat_${product.category}`)}</a> <span>/</span> 
                <strong style="color:var(--primary-color);">${this.language === 'zh' ? product.name : product.name_en}</strong>
            </div>

            <!-- 产品核心展示区 -->
            <div class="product-hero">
                <!-- 左侧画廊 -->
                <div class="gallery-main">
                    <img id="main-image" src="${mainImage}" alt="${this.language === 'zh' ? product.name : product.name_en}">
                </div>
                <div class="gallery-thumbs">
                    ${thumbImages.map((thumb, index) => `
                        <div class="thumb ${index === 0 ? 'active' : ''}" onclick="changeImage(this, '${images[index].replace('w=800', 'w=1200')}')">
                            <img src="${thumb}" alt="Thumb ${index + 1}">
                        </div>
                    `).join('')}
                </div>

                <!-- 右侧信息 -->
                <div class="product-meta">
                    <div class="category">${this.language === 'zh' ? category.name : category.name_en}</div>
                    <h1>${this.language === 'zh' ? product.name : product.name_en}</h1>
                    <div class="desc">${this.language === 'zh' ? product.full_description : product.full_description_en}</div>
                    
                    <!-- 颜色选择 -->
                    <div class="options-group">
                        <h4 data-i18n="spec_color">${this.translate('spec_color')}</h4>
                        ${colorOptions}
                    </div>
                    
                    <!-- 规格参数 -->
                    <div class="options-group">
                        <h4 data-i18n="spec_details">${this.translate('spec_details')}</h4>
                        ${specsHtml}
                    </div>
                    
                    <!-- 操作按钮 -->
                    <div class="action-btns">
                        <a href="contact.html" class="btn-primary" data-i18n="btn_quote">${this.translate('btn_quote')}</a>
                        <a href="contact.html" class="btn-secondary" data-i18n="btn_showroom">${this.translate('btn_showroom')}</a>
                    </div>
                </div>
            </div>

            <!-- 深度图文详情区 -->
            <div class="detail-section">
                <div class="detail-content">
                    <h2>${this.language === 'zh' ? '产品细节' : 'Product Details'}</h2>
                    <p>${this.language === 'zh' ? product.full_description : product.full_description_en}</p>
                    ${images.slice(1).map(img => `
                        <img src="${img.replace('w=800', 'w=800')}" alt="Detail image">
                    `).join('')}
                </div>
            </div>
        `;
    }

    translate(key) {
        const translations = {
            zh: {
                nav_home: "首页",
                nav_products: "产品中心",
                cat_living: "客厅系列",
                cat_bedroom: "卧室系列", 
                cat_dining: "餐厅系列",
                cat_office: "商用办公",
                error_not_found: "未找到该产品",
                spec_color: "可选皮质颜色 / Colors",
                spec_details: "产品参数 / Specifications",
                btn_quote: "获取专属报价",
                btn_showroom: "预约展厅体验"
            },
            en: {
                nav_home: "Home",
                nav_products: "Products",
                cat_living: "Living Room",
                cat_bedroom: "Bedroom",
                cat_dining: "Dining Room",
                cat_office: "Office",
                error_not_found: "Product not found",
                spec_color: "Available Leather Colors",
                spec_details: "Specifications",
                btn_quote: "Get Custom Quote",
                btn_showroom: "Book Showroom Visit"
            }
        };
        return translations[this.language]?.[key] || key;
    }

    async init() {
        // 显示加载状态
        document.getElementById('product-content').innerHTML = `
            <div class="loading">${this.translate('loading')}</div>
        `;

        // 加载产品数据
        const data = await this.loadProducts();
        if (!data) {
            document.getElementById('product-content').innerHTML = `
                <div class="error">加载失败，请稍后重试</div>
            `;
            return;
        }

        this.currentProductId = this.getProductIdFromUrl();
        const product = this.getProductById(this.currentProductId);
        const category = this.getCategoryById(product?.category);

        // 生成并显示产品内容
        const htmlContent = this.generateProductHTML(product, category);
        document.getElementById('product-content').innerHTML = htmlContent;
        
        // 重新绑定事件监听器
        this.bindEventListeners();
    }

    bindEventListeners() {
        // 语言切换监听
        const langToggleBtn = document.getElementById('lang-toggle');
        if (langToggleBtn) {
            langToggleBtn.addEventListener('click', () => {
                this.language = localStorage.getItem('site_lang') === 'zh' ? 'en' : 'zh';
                // 重新加载页面内容
                this.init();
            });
        }
    }
}

// 全局函数供HTML调用
function changeImage(element, imgUrl) {
    const mainImg = document.getElementById('main-image');
    if (mainImg) {
        mainImg.style.opacity = 0;
        setTimeout(() => {
            mainImg.src = imgUrl;
            mainImg.style.opacity = 1;
        }, 200);
    }
    
    document.querySelectorAll('.thumb').forEach(t => t.classList.remove('active'));
    element.classList.add('active');
}

function selectColor(element) {
    document.querySelectorAll('.color-swatch').forEach(c => c.classList.remove('active'));
    element.classList.add('active');
}

// 页面加载时初始化
document.addEventListener('DOMContentLoaded', async () => {
    const loader = new ProductLoader();
    await loader.init();
});