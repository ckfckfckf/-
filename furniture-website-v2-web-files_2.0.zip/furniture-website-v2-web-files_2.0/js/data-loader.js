/**
 * 家具网站数据加载器
 * 用于动态加载产品和工程案例数据
 */

class FurnitureDataLoader {
    constructor() {
        this.products = [];
        this.projects = [];
        this.categories = [];
        this.loaded = false;
    }

    // 加载所有数据
    async loadAllData() {
        try {
            const [productsResponse, projectsResponse] = await Promise.all([
                fetch('data/products.json'),
                fetch('data/projects.json')
            ]);
            
            const productsData = await productsResponse.json();
            const projectsData = await projectsResponse.json();
            
            this.products = productsData.items || [];
            this.categories = productsData.categories || [];
            this.projects = projectsData.items || [];
            this.loaded = true;
            
            return { success: true };
        } catch (error) {
            console.error('Failed to load data:', error);
            return { success: false, error: error.message };
        }
    }

    // 根据ID获取产品
    getProductById(productId) {
        return this.products.find(product => product.id === productId);
    }

    // 根据分类获取产品
    getProductsByCategory(categoryId) {
        return this.products.filter(product => product.category === categoryId);
    }

    // 获取所有分类
    getCategories() {
        return this.categories;
    }

    // 获取所有工程案例
    getProjects() {
        return this.projects;
    }

    // 根据ID获取工程案例
    getProjectById(projectId) {
        return this.projects.find(project => project.id === projectId);
    }
}

// 全局实例
const furnitureData = new FurnitureDataLoader();

// 自动加载数据（如果页面需要）
document.addEventListener('DOMContentLoaded', async () => {
    // 检查页面是否需要数据
    const needsData = document.querySelector('[data-load-products], [data-load-projects]');
    if (needsData && !furnitureData.loaded) {
        await furnitureData.loadAllData();
    }
});