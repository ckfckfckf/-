// 全局变量
let products = [];
let categories = [];
let categoryChart = null;
let productsChart = null;

// API基础URL
const API_BASE_URL = 'http://localhost:3000/api';

// 页面加载完成后初始化
document.addEventListener('DOMContentLoaded', function() {
    // 初始化导航
    initNavigation();
    
    // 初始化模态框
    initModals();
    
    // 初始化数据
    loadData();
    
    // 初始化表单提交
    initForms();
});

// 初始化导航
function initNavigation() {
    const navLinks = document.querySelectorAll('.nav a');
    const sections = document.querySelectorAll('.section');
    
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            
            // 移除所有活动状态
            navLinks.forEach(l => l.classList.remove('active'));
            sections.forEach(s => s.classList.remove('active'));
            
            // 添加当前活动状态
            this.classList.add('active');
            const targetId = this.getAttribute('href').substring(1);
            document.getElementById(targetId).classList.add('active');
            
            // 如果切换到可视化页面，更新图表
            if (targetId === 'visualization') {
                updateProductsChart();
            }
        });
    });
}

// 初始化模态框
function initModals() {
    // 产品模态框
    const productModal = document.getElementById('product-modal');
    const addProductBtn = document.getElementById('add-product-btn');
    const closeProductModal = productModal.querySelector('.close');
    
    addProductBtn.addEventListener('click', function() {
        openProductModal();
    });
    
    closeProductModal.addEventListener('click', function() {
        productModal.style.display = 'none';
    });
    
    // 分类模态框
    const categoryModal = document.getElementById('category-modal');
    const addCategoryBtn = document.getElementById('add-category-btn');
    const closeCategoryModal = categoryModal.querySelector('.close');
    
    addCategoryBtn.addEventListener('click', function() {
        openCategoryModal();
    });
    
    closeCategoryModal.addEventListener('click', function() {
        categoryModal.style.display = 'none';
    });
    
    // 点击模态框外部关闭
    window.addEventListener('click', function(e) {
        if (e.target === productModal) {
            productModal.style.display = 'none';
        }
        if (e.target === categoryModal) {
            categoryModal.style.display = 'none';
        }
    });
}

// 加载数据
function loadData() {
    // 加载产品
    fetch(`${API_BASE_URL}/products`)
        .then(response => response.json())
        .then(data => {
            products = data;
            renderProducts();
            updateDashboard();
        })
        .catch(error => console.error('Error loading products:', error));
    
    // 加载分类
    fetch(`${API_BASE_URL}/categories`)
        .then(response => response.json())
        .then(data => {
            categories = data;
            renderCategories();
            updateCategoryOptions();
            updateDashboard();
        })
        .catch(error => console.error('Error loading categories:', error));
}

// 初始化表单
function initForms() {
    // 产品表单
    const productForm = document.getElementById('product-form');
    productForm.addEventListener('submit', function(e) {
        e.preventDefault();
        submitProductForm();
    });
    
    // 分类表单
    const categoryForm = document.getElementById('category-form');
    categoryForm.addEventListener('submit', function(e) {
        e.preventDefault();
        submitCategoryForm();
    });
}

// 渲染产品列表
function renderProducts() {
    const productsList = document.getElementById('products-list');
    productsList.innerHTML = '';
    
    products.forEach(product => {
        const productCard = document.createElement('div');
        productCard.className = 'product-card';
        productCard.innerHTML = `
            <h3>${product.name}</h3>
            <p>${product.short_description || '无描述'}</p>
            <p><strong>分类:</strong> ${getCategoryName(product.category)}</p>
            <p><strong>价格:</strong> ${product.price_range || '未设置'}</p>
            <div class="card-actions">
                <button class="edit-btn" onclick="editProduct('${product.id}')">编辑</button>
                <button class="delete-btn" onclick="deleteProduct('${product.id}')">删除</button>
            </div>
        `;
        productsList.appendChild(productCard);
    });
}

// 渲染分类列表
function renderCategories() {
    const categoriesList = document.getElementById('categories-list');
    categoriesList.innerHTML = '';
    
    categories.forEach(category => {
        const categoryCard = document.createElement('div');
        categoryCard.className = 'category-card';
        categoryCard.innerHTML = `
            <h3>${category.name}</h3>
            <p>${category.description || '无描述'}</p>
            <div class="card-actions">
                <button class="edit-btn" onclick="editCategory('${category.id}')">编辑</button>
                <button class="delete-btn" onclick="deleteCategory('${category.id}')">删除</button>
            </div>
        `;
        categoriesList.appendChild(categoryCard);
    });
}

// 更新分类选项
function updateCategoryOptions() {
    const categorySelect = document.getElementById('product-category');
    categorySelect.innerHTML = '';
    
    categories.forEach(category => {
        const option = document.createElement('option');
        option.value = category.id;
        option.textContent = category.name;
        categorySelect.appendChild(option);
    });
}

// 更新仪表盘
function updateDashboard() {
    // 更新产品总数
    document.getElementById('total-products').textContent = products.length;
    
    // 更新分类总数
    document.getElementById('total-categories').textContent = categories.length;
    
    // 更新分类图表
    updateCategoryChart();
}

// 更新分类图表
function updateCategoryChart() {
    const ctx = document.getElementById('category-chart').getContext('2d');
    
    // 计算每个分类的产品数量
    const categoryCounts = {};
    categories.forEach(category => {
        categoryCounts[category.id] = 0;
    });
    
    products.forEach(product => {
        if (categoryCounts[product.category] !== undefined) {
            categoryCounts[product.category]++;
        }
    });
    
    const labels = categories.map(category => category.name);
    const data = labels.map(label => {
        const category = categories.find(c => c.name === label);
        return categoryCounts[category.id] || 0;
    });
    
    // 销毁旧图表
    if (categoryChart) {
        categoryChart.destroy();
    }
    
    // 创建新图表
    categoryChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                label: '产品数量',
                data: data,
                backgroundColor: '#D4AF37',
                borderColor: '#b8962f',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        precision: 0
                    }
                }
            }
        }
    });
}

// 更新产品图表
function updateProductsChart() {
    const ctx = document.getElementById('products-chart').getContext('2d');
    
    // 计算每个分类的产品数量
    const categoryCounts = {};
    categories.forEach(category => {
        categoryCounts[category.id] = 0;
    });
    
    products.forEach(product => {
        if (categoryCounts[product.category] !== undefined) {
            categoryCounts[product.category]++;
        }
    });
    
    const labels = categories.map(category => category.name);
    const data = labels.map(label => {
        const category = categories.find(c => c.name === label);
        return categoryCounts[category.id] || 0;
    });
    
    // 销毁旧图表
    if (productsChart) {
        productsChart.destroy();
    }
    
    // 创建新图表
    productsChart = new Chart(ctx, {
        type: 'pie',
        data: {
            labels: labels,
            datasets: [{
                data: data,
                backgroundColor: [
                    '#D4AF37',
                    '#2c2c2c',
                    '#4CAF50',
                    '#2196F3',
                    '#FF9800',
                    '#9C27B0'
                ],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true
        }
    });
}

// 打开产品模态框
function openProductModal(product = null) {
    const modal = document.getElementById('product-modal');
    const modalTitle = document.getElementById('modal-title');
    const productId = document.getElementById('product-id');
    const productIdInput = document.getElementById('product-id-input');
    const productCategory = document.getElementById('product-category');
    const productName = document.getElementById('product-name');
    const productNameEn = document.getElementById('product-name-en');
    const productShortDesc = document.getElementById('product-short-desc');
    const productShortDescEn = document.getElementById('product-short-desc-en');
    const productFullDesc = document.getElementById('product-full-desc');
    const productFullDescEn = document.getElementById('product-full-desc-en');
    const productPrice = document.getElementById('product-price');
    const productImages = document.getElementById('product-images');
    const productTags = document.getElementById('product-tags');
    
    if (product) {
        modalTitle.textContent = '编辑产品';
        productId.value = product.id;
        productIdInput.value = product.id;
        productCategory.value = product.category;
        productName.value = product.name;
        productNameEn.value = product.name_en || '';
        productShortDesc.value = product.short_description || '';
        productShortDescEn.value = product.short_description_en || '';
        productFullDesc.value = product.full_description || '';
        productFullDescEn.value = product.full_description_en || '';
        productPrice.value = product.price_range || '';
        productImages.value = product.images ? product.images.join(',') : '';
        productTags.value = product.tags ? product.tags.join(',') : '';
    } else {
        modalTitle.textContent = '添加产品';
        productId.value = '';
        productIdInput.value = '';
        productCategory.value = categories.length > 0 ? categories[0].id : '';
        productName.value = '';
        productNameEn.value = '';
        productShortDesc.value = '';
        productShortDescEn.value = '';
        productFullDesc.value = '';
        productFullDescEn.value = '';
        productPrice.value = '';
        productImages.value = '';
        productTags.value = '';
    }
    
    modal.style.display = 'block';
}

// 打开分类模态框
function openCategoryModal(category = null) {
    const modal = document.getElementById('category-modal');
    const modalTitle = document.getElementById('category-modal-title');
    const categoryId = document.getElementById('category-id');
    const categoryIdInput = document.getElementById('category-id-input');
    const categoryName = document.getElementById('category-name');
    const categoryNameEn = document.getElementById('category-name-en');
    const categoryDesc = document.getElementById('category-desc');
    const categoryDescEn = document.getElementById('category-desc-en');
    const categoryImage = document.getElementById('category-image');
    
    if (category) {
        modalTitle.textContent = '编辑分类';
        categoryId.value = category.id;
        categoryIdInput.value = category.id;
        categoryName.value = category.name;
        categoryNameEn.value = category.name_en || '';
        categoryDesc.value = category.description || '';
        categoryDescEn.value = category.description_en || '';
        categoryImage.value = category.image || '';
    } else {
        modalTitle.textContent = '添加分类';
        categoryId.value = '';
        categoryIdInput.value = '';
        categoryName.value = '';
        categoryNameEn.value = '';
        categoryDesc.value = '';
        categoryDescEn.value = '';
        categoryImage.value = '';
    }
    
    modal.style.display = 'block';
}

// 提交产品表单
function submitProductForm() {
    const productId = document.getElementById('product-id').value;
    const productData = {
        id: document.getElementById('product-id-input').value,
        category: document.getElementById('product-category').value,
        name: document.getElementById('product-name').value,
        name_en: document.getElementById('product-name-en').value,
        short_description: document.getElementById('product-short-desc').value,
        short_description_en: document.getElementById('product-short-desc-en').value,
        full_description: document.getElementById('product-full-desc').value,
        full_description_en: document.getElementById('product-full-desc-en').value,
        price_range: document.getElementById('product-price').value,
        images: document.getElementById('product-images').value.split(',').map(img => img.trim()).filter(img => img),
        tags: document.getElementById('product-tags').value.split(',').map(tag => tag.trim()).filter(tag => tag)
    };
    
    let url = `${API_BASE_URL}/products`;
    let method = 'POST';
    
    if (productId) {
        url = `${API_BASE_URL}/products/${productId}`;
        method = 'PUT';
    }
    
    fetch(url, {
        method: method,
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(productData)
    })
    .then(response => response.json())
    .then(data => {
        document.getElementById('product-modal').style.display = 'none';
        loadData();
    })
    .catch(error => console.error('Error submitting product:', error));
}

// 提交分类表单
function submitCategoryForm() {
    const categoryId = document.getElementById('category-id').value;
    const categoryData = {
        id: document.getElementById('category-id-input').value,
        name: document.getElementById('category-name').value,
        name_en: document.getElementById('category-name-en').value,
        description: document.getElementById('category-desc').value,
        description_en: document.getElementById('category-desc-en').value,
        image: document.getElementById('category-image').value
    };
    
    let url = `${API_BASE_URL}/categories`;
    let method = 'POST';
    
    if (categoryId) {
        url = `${API_BASE_URL}/categories/${categoryId}`;
        method = 'PUT';
    }
    
    fetch(url, {
        method: method,
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(categoryData)
    })
    .then(response => response.json())
    .then(data => {
        document.getElementById('category-modal').style.display = 'none';
        loadData();
    })
    .catch(error => console.error('Error submitting category:', error));
}

// 编辑产品
function editProduct(id) {
    const product = products.find(p => p.id === id);
    if (product) {
        openProductModal(product);
    }
}

// 编辑分类
function editCategory(id) {
    const category = categories.find(c => c.id === id);
    if (category) {
        openCategoryModal(category);
    }
}

// 删除产品
function deleteProduct(id) {
    if (confirm('确定要删除这个产品吗？')) {
        fetch(`${API_BASE_URL}/products/${id}`, {
            method: 'DELETE'
        })
        .then(response => response.json())
        .then(data => {
            loadData();
        })
        .catch(error => console.error('Error deleting product:', error));
    }
}

// 删除分类
function deleteCategory(id) {
    if (confirm('确定要删除这个分类吗？')) {
        fetch(`${API_BASE_URL}/categories/${id}`, {
            method: 'DELETE'
        })
        .then(response => response.json())
        .then(data => {
            loadData();
        })
        .catch(error => console.error('Error deleting category:', error));
    }
}

// 获取分类名称
function getCategoryName(categoryId) {
    const category = categories.find(c => c.id === categoryId);
    return category ? category.name : '未知分类';
}
