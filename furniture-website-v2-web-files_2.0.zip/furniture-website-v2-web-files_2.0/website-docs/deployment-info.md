# 部署信息

## 服务器信息
- **公网 IP**: 47.252.74.114
- **服务器类型**: Alibaba Cloud ECS
- **操作系统**: Linux (Alibaba Cloud Linux)
- **Web 服务器**: Nginx

## 部署路径
- **Nginx 网站根目录**: `/usr/share/nginx/html/`
- **项目源码目录**: `/home/admin/.openclaw/workspace/furniture-website-v2/`
- **构建输出目录**: `/home/admin/.openclaw/workspace/furniture-website-v2/dist/`

## 部署命令
```bash
# 构建网站
cd /home/admin/.openclaw/workspace/furniture-website-v2
python build.py

# 部署到生产环境
sudo cp -r dist/* /usr/share/nginx/html/
```

## 访问地址
- **主站**: http://47.252.74.114
- **产品中心**: http://47.252.74.114/products.html
- **工程案例**: http://47.252.74.114/contact.html
- **产品详情**: http://47.252.74.114/product-detail.html

## 维护说明
- 所有内容修改请先编辑 `data/` 目录下的 JSON 文件
- 修改后运行 `python build.py` 生成新版本
- 使用 `sudo cp -r dist/* /usr/share/nginx/html/` 部署更新
- 备份文件保存在 `/usr/share/nginx/html-backup/`