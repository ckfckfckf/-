# 数据结构说明

## 目录结构
```
data/
├── products.json      # 产品数据
├── projects.json      # 工程案例数据  
├── categories.json    # 产品分类数据
└── README.md         # 本说明文件
```

## 文件格式说明

### products.json
包含所有产品的详细信息，每个产品包含：
- `id`: 唯一标识符（用于URL）
- `category`: 分类ID（对应categories.json）
- `name`/`name_en`: 中英文名称
- `description`/`description_en`: 中英文描述
- `images`: 图片URL数组
- `specs`: 规格参数（可选）
- `price`: 价格信息（可选）

### projects.json  
包含工程案例数据，格式类似products.json。

### categories.json
产品分类定义，包含中英文名称和描述。

## 使用方法
1. 添加新产品：在`products.json`的`items`数组中添加新对象
2. 添加新分类：在`categories.json`中添加新分类
3. 添加工程案例：在`projects.json`中添加新项目

所有数据都会被前端自动加载和使用。