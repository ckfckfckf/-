const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = 3000;

// 中间件
app.use(cors());
app.use(bodyParser.json());
app.use(express.static('public'));

// 数据文件路径
const PRODUCTS_PATH = path.join(__dirname, '..', 'data', 'products.json');
const PROJECTS_PATH = path.join(__dirname, '..', 'data', 'projects.json');

// 读取数据文件
function readData(filePath) {
  try {
    const data = fs.readFileSync(filePath, 'utf8');
    return JSON.parse(data);
  } catch (error) {
    console.error('Error reading data file:', error);
    return { categories: [], products: [] };
  }
}

// 写入数据文件
function writeData(filePath, data) {
  try {
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2), 'utf8');
    return true;
  } catch (error) {
    console.error('Error writing data file:', error);
    return false;
  }
}

// API路由

// 获取所有产品
app.get('/api/products', (req, res) => {
  const data = readData(PRODUCTS_PATH);
  res.json(data.products);
});

// 获取单个产品
app.get('/api/products/:id', (req, res) => {
  const data = readData(PRODUCTS_PATH);
  const product = data.products.find(p => p.id === req.params.id);
  if (product) {
    res.json(product);
  } else {
    res.status(404).json({ error: 'Product not found' });
  }
});

// 创建新产品
app.post('/api/products', (req, res) => {
  const data = readData(PRODUCTS_PATH);
  const newProduct = req.body;
  data.products.push(newProduct);
  if (writeData(PRODUCTS_PATH, data)) {
    res.status(201).json(newProduct);
  } else {
    res.status(500).json({ error: 'Failed to create product' });
  }
});

// 更新产品
app.put('/api/products/:id', (req, res) => {
  const data = readData(PRODUCTS_PATH);
  const index = data.products.findIndex(p => p.id === req.params.id);
  if (index !== -1) {
    data.products[index] = req.body;
    if (writeData(PRODUCTS_PATH, data)) {
      res.json(req.body);
    } else {
      res.status(500).json({ error: 'Failed to update product' });
    }
  } else {
    res.status(404).json({ error: 'Product not found' });
  }
});

// 删除产品
app.delete('/api/products/:id', (req, res) => {
  const data = readData(PRODUCTS_PATH);
  const filteredProducts = data.products.filter(p => p.id !== req.params.id);
  if (filteredProducts.length !== data.products.length) {
    data.products = filteredProducts;
    if (writeData(PRODUCTS_PATH, data)) {
      res.json({ message: 'Product deleted successfully' });
    } else {
      res.status(500).json({ error: 'Failed to delete product' });
    }
  } else {
    res.status(404).json({ error: 'Product not found' });
  }
});

// 获取所有分类
app.get('/api/categories', (req, res) => {
  const data = readData(PRODUCTS_PATH);
  res.json(data.categories);
});

// 创建新分类
app.post('/api/categories', (req, res) => {
  const data = readData(PRODUCTS_PATH);
  const newCategory = req.body;
  data.categories.push(newCategory);
  if (writeData(PRODUCTS_PATH, data)) {
    res.status(201).json(newCategory);
  } else {
    res.status(500).json({ error: 'Failed to create category' });
  }
});

// 更新分类
app.put('/api/categories/:id', (req, res) => {
  const data = readData(PRODUCTS_PATH);
  const index = data.categories.findIndex(c => c.id === req.params.id);
  if (index !== -1) {
    data.categories[index] = req.body;
    if (writeData(PRODUCTS_PATH, data)) {
      res.json(req.body);
    } else {
      res.status(500).json({ error: 'Failed to update category' });
    }
  } else {
    res.status(404).json({ error: 'Category not found' });
  }
});

// 删除分类
app.delete('/api/categories/:id', (req, res) => {
  const data = readData(PRODUCTS_PATH);
  const filteredCategories = data.categories.filter(c => c.id !== req.params.id);
  if (filteredCategories.length !== data.categories.length) {
    data.categories = filteredCategories;
    if (writeData(PRODUCTS_PATH, data)) {
      res.json({ message: 'Category deleted successfully' });
    } else {
      res.status(500).json({ error: 'Failed to delete category' });
    }
  } else {
    res.status(404).json({ error: 'Category not found' });
  }
});

// 启动服务器
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
