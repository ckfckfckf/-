# 网站维护指南

## 目录结构说明

```
furniture-website-v2/
├── src/              # 源文件模板（不要直接修改）
├── data/             # 数据文件（主要编辑这里）
│   ├── products.json # 产品数据
│   └── projects.json # 工程案例数据
├── dist/             # 构建输出目录（部署用）
├── build.py          # 构建脚本
└── website-docs/     # 本文档所在目录
```

## 添加新产品

1. 编辑 `data/products.json`
2. 在 `products` 数组中添加新对象
3. 运行 `python build.py`
4. 部署 `dist/` 目录到服务器

## 添加工程案例

1. 编辑 `data/projects.json`
2. 在 `projects` 数组中添加新对象
3. 运行 `python build.py`
4. 部署 `dist/` 目录到服务器

## 重新部署步骤

```bash
# 1. 进入项目目录
cd /home/admin/.openclaw/workspace/furniture-website-v2

# 2. 运行构建
python build.py

# 3. 复制到 Nginx 目录
sudo cp -r dist/* /usr/share/nginx/html/

# 4. 验证访问
# http://47.252.74.114
```

## 故障排除

- **网站无法访问**：检查 Nginx 服务状态 `sudo systemctl status nginx`
- **图片不显示**：确认 `videos/` 目录和图片文件已正确复制
- **多语言切换失效**：检查 JSON 数据中的翻译键值是否完整