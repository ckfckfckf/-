# 网站文档目录

这个目录用于保存家具网站的所有相关文档、配置和维护信息。

## 目录结构说明

- **architecture.md** - 网站架构设计说明
- **deployment.md** - 部署配置和服务器信息  
- **maintenance.md** - 日常维护指南
- **todo.md** - 待办事项和改进计划
- **backup/** - 备份文件和历史版本

## 快速访问

- **当前部署地址**: http://47.252.74.114
- **源代码位置**: `/home/admin/.openclaw/workspace/furniture-website-v2/`
- **Nginx 目录**: `/usr/share/nginx/html/`
- **数据文件**: `/home/admin/.openclaw/workspace/furniture-website-v2/data/`

---
最后更新: 2026-02-24
维护者: 成凯丰